# 场景包索引

场景包不是固定题库，而是动态问题生成的能力地图。

## 选择规则

| 岗位/场景 | 主场景包 | 可叠加 |
|---|---|---|
| 通用求职 | job-interview.md | career-switch.md |
| 新媒体主管/运营/内容策划 | new-media-operations.md | management-review.md |
| 销售/课程顾问/客服转化 | sales-practical.md | job-interview.md |
| 运营主管/活动运营/用户运营 | operations-general.md | management-review.md |
| 技术负责人/开发主管 | technical-leadership.md | management-review.md |
| 管理岗/主管 | management-review.md | job-interview.md |
| 跨行业/转岗 | career-switch.md | 目标岗位包 |
| 融资路演模拟 | fundraising-roadshow.md | project-defense.md |
| 项目答辩 | project-defense.md | management-review.md |
| 校招/实习 | campus-intern.md | job-interview.md |

## 使用规则

1. 先读主场景包。
2. 岗位混合时可叠加第二包，例如“新媒体主管”叠加管理包。
3. 不得照搬问题，要结合候选人材料动态生成。
4. 每轮只取当前最关键的 1 个问题。
