# v1.0.9 审计清单

## 本次修复

- [x] 企业流程面试中，候选人要求“现在二面/直接老板面”不会直接切换。
- [x] 一次性综合/模拟面试可切换角色，但必须先说明切换身份与考察重点。
- [x] 企业面试结尾只给候选人外部话术，内部报告通过管理员口令或内部模式查看。
- [x] 候选人结束后继续追问薪资、老板、结果、二面时，记录到待回复/转达清单，不继续长篇对话。
- [x] 管理员口令配置已加入 `config/admin-config-template.md`。
- [x] 新增 `references/round-transition-policy.md`。
- [x] 新增 `references/admin-console.md`。
- [x] `SKILL.md` 已引用新增文件。

## 保留能力

- [x] PDF/图片/文字简历与JD接入。
- [x] 多页PDF摘要与候选人档案。
- [x] 简历时间线审计。
- [x] 候选人声明账本与核验追问。
- [x] 候选人反问处理。
- [x] 面试节奏控制。
- [x] HR初面/业务二面/老板终面。
- [x] 上下文胶囊与 Candidate Dossier。
- [x] 场景包机制。

## 校验结果

`SKILL.md` 引用的 reference/config/packs 文件均已存在。
